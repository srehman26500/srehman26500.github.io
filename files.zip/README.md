# Zara Malik — Copywriter Portfolio

A clean, professional single-page portfolio for a freelance copywriter. Built in pure HTML, CSS, and vanilla JavaScript — no frameworks, no dependencies.

## 🚀 Live Site

Hosted on GitHub Pages: `https://yourusername.github.io/`

---

## 📁 Files

| File | Description |
|------|-------------|
| `index.html` | The complete portfolio (single file — all CSS & JS included) |
| `README.md` | This file |

---

## 🌐 How to Host on GitHub Pages (Step-by-Step)

### Step 1 — Create a GitHub account
Go to [github.com](https://github.com) and sign up if you haven't already.

### Step 2 — Create a new repository
1. Click the **+** icon (top right) → **New repository**
2. Name it exactly: `yourusername.github.io`  
   *(Replace `yourusername` with your actual GitHub username — this is important!)*
3. Set it to **Public**
4. Click **Create repository**

### Step 3 — Upload your files
1. Inside the new repository, click **Add file** → **Upload files**
2. Drag and drop `index.html` and `README.md`
3. Scroll down and click **Commit changes**

### Step 4 — Enable GitHub Pages
1. Go to your repository → **Settings** tab
2. Scroll to **Pages** in the left sidebar
3. Under **Source**, select **Deploy from a branch**
4. Choose branch: `main` and folder: `/ (root)`
5. Click **Save**

### Step 5 — Your site is live!
After 1–2 minutes, visit:  
`https://yourusername.github.io`

---

## ✏️ Before You Go Live — Update These Placeholders

Open `index.html` and search for these items to personalise:

| Placeholder | What to replace with |
|------------|----------------------|
| `hello@zaramalik.com` | Your real email address |
| `+92 300 123 4567` | Your real WhatsApp number |
| `https://wa.me/923001234567` | Your real WhatsApp link |
| `linkedin.com/in/yourprofile` | Your real LinkedIn URL |
| `© 2025 Zara Malik` | Update year if needed |

---

## 🔧 Features

- Sticky navigation with scroll-aware active links
- Mobile-responsive hamburger menu
- Scroll-reveal animations on all sections
- Back-to-top button
- SEO meta tags + Open Graph tags
- No external dependencies (except Google Fonts)
- Single `.html` file — no build step needed

---

## 📞 Contact

For copywriting enquiries, visit the live portfolio or reach out directly via the contact details on the site.
